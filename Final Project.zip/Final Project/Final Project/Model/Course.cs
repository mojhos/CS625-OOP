﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Model
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CourseCode { get; set; }
        public int Credits { get; set; }
        public int InstructorId { get; set; }
        public Instructor Instructor { get; set; }
        public int DepartmentId { get; set; }
        public Department Department { get; set; }
        public List<Enrollment> Enrollments { get; set; }
    }

}
