﻿using Final_Project.Model;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ConsoleTables;
class Program
{
    static void Main(string[] args)
    {
        bool exit = false;

        // Ensure database is created
        using (var context = new UniContext())
        {
            context.Database.EnsureCreated();
        }

        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("Welcome to the University Management System");
            Console.WriteLine("1. Admin Menu");
            Console.WriteLine("2. Student Menu");
            Console.WriteLine("3. Exit");
            Console.Write("Select an option: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AdminMenu();
                    break;
                case "2":
                    SelectStudent();
                    break;
                case "3":
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }

    static void AdminMenu()
    {
        bool exit = false;
        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("Admin Menu");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Add Instructor");
            Console.WriteLine("3. Add Course");
            Console.WriteLine("4. Add Department");
            Console.WriteLine("5. View All Courses");
            Console.WriteLine("6. Back to Main Menu");
            Console.Write("Select an option: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddStudent();
                    break;
                case "2":
                    AddInstructor();
                    break;
                case "3":
                    AddCourse();
                    break;
                case "4":
                    AddDepartment();
                    break;
                case "5":
                    ViewCourses();
                    Console.WriteLine("Press any key to go back to the menu...");
                    Console.ReadKey();
                    break;
                case "6":
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }

    static void SelectStudent()
    {
        int studentId;
        bool exit = false;
        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("Student Menu");
            Console.WriteLine("1. Add a Student");
            Console.WriteLine("2. Select a Student");
            Console.WriteLine("3. Exit");
            Console.Write("Select an option: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    StudentMenu(AddStudent());
                    break;
                case "2":
                    StudentMenu(ViewStudents());
                    break;
                case "3":
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }

    static Student ViewStudents()
    {
        using (var context = new UniContext())
        {
            var students = context.Students.ToList();
            Console.Clear();
            Console.WriteLine("Available Students:");
            var table = new ConsoleTable(new ConsoleTableOptions
            {
                Columns = ["ID", "Student Name", "Student Email"],
                EnableCount = false
            });
            foreach (var student in students)
            {
                table.AddRow(student.Id, student.Name, student.Email);
            }
            table.Write();
            Console.Write("Please select a student by ID: ");
            int id = int.Parse(Console.ReadLine());
            return students.FirstOrDefault(a => a.Id == id);

        }
    }

    static void StudentMenu(Student student)
    {
        using (var context = new UniContext())
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("Student Menu");
                Console.WriteLine("1. View Courses");
                Console.WriteLine("2. Enroll in Course");
                Console.WriteLine("3. View Enrolled Courses");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ViewCourses();
                        break;
                    case "2":
                        EnrollInCourse(student);
                        break;
                    case "3":
                        ViewEnrolledCourses(student);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }
    }

    static Student AddStudent()
    {
        Console.Clear();
        Console.Write("Enter Student Name: ");
        string name = Console.ReadLine();

        Console.Write("Enter Student Email: ");
        string email = Console.ReadLine();

        using (var context = new UniContext())
        {
            var student = new Student { Name = name, Email = email };
            context.Students.Add(student);
            context.SaveChanges();
            return student;
        }
        
        Console.WriteLine("Student Added Successfully!");
        Console.ReadKey();
    }

    static void AddInstructor()
    {
        Console.Clear();
        Console.Write("Enter Instructor Name: ");
        string name = Console.ReadLine();

        Console.Write("Enter Instructor Email: ");
        string email = Console.ReadLine();

        using (var context = new UniContext())
        {
            var instructor = new Instructor { Name = name, Email = email };
            context.Instructors.Add(instructor);
            context.SaveChanges();
        }

        Console.WriteLine("Instructor Added Successfully!");
        Console.ReadKey();
    }

    static void AddCourse()
    {
        Console.Clear();
        Console.Write("Enter Course Name: ");
        string courseName = Console.ReadLine();

        Console.Write("Enter Course Code: ");
        string courseCode = Console.ReadLine();

        Console.Write("Enter Credits: ");
        int credits = int.Parse(Console.ReadLine());

        //Console.Write("Enter Instructor ID: ");
        int instructorId = int.Parse(ViewInstructors());

        //Console.Write("Enter Department ID: ");
        int departmentId = int.Parse(ViewDepartments());

        using (var context = new UniContext())
        {
            var course = new Course
            {
                Name = courseName,
                CourseCode = courseCode,
                Credits = credits,
                InstructorId = instructorId,
                Instructor = context.Instructors.FirstOrDefault(a => a.Id == instructorId),
                DepartmentId = departmentId,
                Department = context.Departments.FirstOrDefault(b => b.Id == departmentId)
            };

            context.Courses.Add(course);
            context.SaveChanges();
        }

        Console.WriteLine("Course Added Successfully!");
        Console.WriteLine("Press any key to go back to main menu...");
        Console.ReadKey();
    }

    static void AddDepartment()
    {
        Console.Clear();
        Console.Write("Enter Department Name: ");
        string departmentName = Console.ReadLine();

        using (var context = new UniContext())
        {
            var department = new Department { DepartmentName = departmentName };
            context.Departments.Add(department);
            context.SaveChanges();
        }

        Console.WriteLine("Department Added Successfully!");
        Console.ReadKey();
    }

    static void ViewCourses()
    {
        using (var context = new UniContext())
        {
            var courses = context.Courses.Include(c => c.Instructor).Include(c => c.Department).ToList();
            Console.Clear();
            Console.WriteLine("Available Courses:");
            var table =new ConsoleTable(new ConsoleTableOptions
            {
                Columns = ["ID", "Course Code", "Course Name", "Credit", "Instructor", "Department"],
                EnableCount = false
            });
            foreach (var course in courses)
            {
                table.AddRow(course.Id, course.CourseCode, course.Name, course.Credits, course.Instructor.Name, course.Department.DepartmentName);
                
            }
            table.Write();
            
            
            
        }
    }

    static string ViewDepartments()
    {
        using (var context = new UniContext())
        {
            var Departments = context.Departments.ToList();
            Console.WriteLine("Available Departments:");
            var table = new ConsoleTable(new ConsoleTableOptions
            {
                Columns = ["ID", "Department Name"],
                EnableCount = false
            });

            foreach (var department in Departments)
            {
                table.AddRow(department.Id, department.DepartmentName);
            }
            table.Write();
            Console.WriteLine("Please select the Deprtment by typing the Id: ");
            string choice = Console.ReadLine();
            return choice;
        }
    }

    static string ViewInstructors()
    {
        using (var context = new UniContext())
        {
            var Instructors = context.Instructors.ToList();
            Console.WriteLine("Available Instructors:");
            var table = new ConsoleTable(new ConsoleTableOptions
            {
                Columns = ["ID", "Instructor Name"],
                EnableCount = false
            });
            foreach (var instructor in Instructors)
            {
                table.AddRow(instructor.Id, instructor.Name);
            }
            table.Write();
            Console.WriteLine("Please select the instructor by typing the Id: ");
            string choice =Console.ReadLine();
            return choice;

        }
    }

    static void EnrollInCourse(Student student)
    {
        Console.Clear();
        ViewCourses();
        Console.Write("Enter Course ID to enroll in: ");
        int courseId = int.Parse(Console.ReadLine());

        using (var context = new UniContext())
        {
            var course = context.Courses.Find(courseId);
            if (course != null)
            {
                var enrollment = new Enrollment
                {
                    StudentId = student.Id,
                    CourseId = courseId
                };

                context.Enrollments.Add(enrollment);
                context.SaveChanges();

                Console.WriteLine($"Enrolled in {course.Name} successfully!");
            }
            else
            {
                Console.WriteLine("Course not found!");
            }
            Console.WriteLine("Please press any key to go back to main menu...");
            Console.ReadKey();
        }
    }

    static void ViewEnrolledCourses(Student student)
    {
        using (var context = new UniContext())
        {
            var enrollments = context.Enrollments
                .Where(e => e.StudentId == student.Id)
                .Include(e => e.Course.Department).Include(e => e.Course.Instructor).Include(e => e.Student)
                .ToList();

            Console.Clear();
            Console.WriteLine("Enrolled Courses:");
            var table = new ConsoleTable(new ConsoleTableOptions
            {
                Columns = ["ID", "Course Code", "Course Name", "Student Name", "Instructor Name", "Department"],
                EnableCount = false
            });
            foreach (var enrollment in enrollments)
            {
                table.AddRow(enrollment.Id, enrollment.Course.CourseCode, enrollment.Course.Name, enrollment.Student.Name,  enrollment.Course.Instructor.Name, enrollment.Course.Department.DepartmentName );
            }
            table.Write();
            Console.WriteLine("Press any key to go back to the menu...");
            Console.ReadKey();
        }
    }
}
